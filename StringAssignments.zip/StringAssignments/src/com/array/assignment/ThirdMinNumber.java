package com.array.assignment;

public class ThirdMinNumber {

	public static void main(String[] args) {
		int[] arr = {23,54,64,21,34,90,12};
		int[] temp = new int[arr.length];
		for(int i=0;i<arr.length;i++) {
			for(int j=i+1;j<arr.length;j++) {
				if(arr[i]>arr[j]) {
					temp[i]=arr[i];
					arr[i]=arr[j];
					arr[j]=temp[i];
				}
			}
			
		}
		
		System.out.print("Actual array of numbers:" +" ");
		int n = 3;
		for(int i=0;i<arr.length;i++) {
			System.out.print(arr[i]+" ");
			//System.out.print(arr[n-1]);
		}
		
		
			
		
		

	}

}
