package com.array.assignment;

import java.util.Arrays;

public class CheckPallindrome {

	public static void main(String[] args) {
		String rev = "";
	     String[] arr = {"BOB", "Monika", "RADAR"};
	     String[] arr1 = new String[arr.length];
	     // System.out.print(arr.length);
	     for(int i=0;i<arr.length;i++) {
	    	 for(int j=arr[i].length()-1;j>=0;j--) {
	    		 rev = rev + arr[i].charAt(j);
	    	 }
			
				  if (arr[i].equals(rev)) {
					  
					  arr1[i] =  arr[i];
					  System.out.println(Arrays.toString(arr1));
				  }
		     }
	   }

	}



