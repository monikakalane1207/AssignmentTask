package com.array.assignment;

public class VowelConsonantCheck {

	public static void main(String[] args) {
		char[] test  = {'a', 'd', 't','e'};
		char[] newTestVowel = new char[test.length];
		char[] newTestConsonant = new char[test.length];
		for( int i=0;i<test.length;i++) {
			if(test[i] == 'a' || test[i] == 'e' || test[i] == 'i' || test[i] == 'o' || test[i] == 'u' )
				newTestVowel[i] = test[i];
			else
	        	newTestConsonant[i] = test[i];
		}

		System.out.print( "List of Vowel are :");
		System.out.println(newTestVowel);
		System.out.print( "List of Consonant are :");
		System.out.println(newTestConsonant);
	}

}
