package com.array.assignment;

public class OddEven {

	public static void main(String[] args) {
		int a[]={1,2,5,6,3,2};  
		System.out.println("Odd Numbers:");  
		for(int i=0;i<a.length;i++){  
			if(a[i]%2!=0){  
				System.out.println(a[i]);  
			}  
		}  
		System.out.println("Even Numbers:");  
		for(int i=0;i<a.length;i++){  
			if(a[i]%2==0){  
				System.out.println(a[i]);  
			}  
		} 
		System.out.println("Prime Numbers:"); 
		for(int i=0; i<a.length; i++){
	        boolean isPrime = true;
	        for (int j=2; j<i; j++){
	        	if(i%j==0){
	                isPrime = false;
	                break;
	            }
	        }
	        if(isPrime)
	            System.out.println(i);
	    }

	}

}
