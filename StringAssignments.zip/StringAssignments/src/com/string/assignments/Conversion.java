package com.string.assignments;

class Conversion
{
	void CapToSmallMethod(String t1){
		char[] ch = t1.toCharArray();
		for(int i=0; i<ch.length;i++) {
			if((ch[i] >= 'A') && (ch[i]<='Z'))
			{
				ch[i] = (char) ((ch[i])+32);
			}
		}
		for(int i=0;i<ch.length;i++) {
			System.out.print(ch[i]);
		}
	}
	
	void SmallToCaps(String smal) {
		char[] ch = smal.toCharArray();
		for(int i=0; i<ch.length;i++) {
			if((ch[i] >= 'a') && (ch[i]<='z'))
			{
				ch[i] = (char) ((ch[i])-32);
			}
		}
		for(int i=0;i<ch.length;i++) {
			System.out.print(ch[i]);
		}
		
	}
	
	public static void main(String args[]){
		Conversion cs = new Conversion();
		String caps = "HELLO ";
		cs.CapToSmallMethod(caps);
		String smal = "world";
		cs.SmallToCaps(smal);
	}
	
}
 