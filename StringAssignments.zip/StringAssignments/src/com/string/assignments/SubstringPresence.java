package com.string.assignments;

public class SubstringPresence {

	public static void main(String[] args) {
		String str = "Yash Tech PVT LTD";
		String str1 = "LTD";
		boolean isFound = str.indexOf(str1) != -1 ? true: false; 
		if(isFound) {
			System.out.println(str1 +" "+ "is found");
		}
		else
		{
			System.out.println("Given String is not present");
		}

	}

}
