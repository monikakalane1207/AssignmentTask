package com.string.assignments;

public class NameToLength {

	void NameToLengthFunction(String str){
		char[] ch = str.toCharArray();
		System.out.print(ch.length);
		}
	public static void main(String[] args) {
		NameToLength obj = new NameToLength();
		String str = "Monika";
		obj.NameToLengthFunction(str);
		}

	}

