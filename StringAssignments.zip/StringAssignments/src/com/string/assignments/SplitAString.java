package com.string.assignments;

public class SplitAString {

	public static void main(String[] args) {
		String arr = splitAString("ABC-DFC-hjgy",'-');
		System.out.print(arr);
		}

	private static String splitAString(String str, char c) {
		char[] ch = str.toCharArray(); 
		int j = 0;
		String str1,temp = "";
		
		for(int i=0 ; i<ch.length ; i++) {
			if(str.charAt(i) != c) {
				temp += Character.toString(str.charAt(i));
			}
			else {
				temp+= " ";
			}
		}
		 str1 = temp;
		 return str1;
		
	}

}
