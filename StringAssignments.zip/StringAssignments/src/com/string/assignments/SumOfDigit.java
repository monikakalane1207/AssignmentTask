package com.string.assignments;

public class SumOfDigit {
	public static void main(String args[]){
	String str = "AEBCD";
	int result =0;
	int sum = 0;
	char[] ch = str.toCharArray();
	for(int i=0; i<ch.length;i++) {
		if(ch[i]>='A' && ch[i]<='Z') {
			sum = ((ch[i] - 'A') + 1);
		}
		result  = result + sum;
	}
	System.out.print(result);
	}
}
